# Robo de lançamentos de hora no Timesheet Magna


## Comandos

### Fechar pacote.

```sh
mvn clean compile assembly:single
```